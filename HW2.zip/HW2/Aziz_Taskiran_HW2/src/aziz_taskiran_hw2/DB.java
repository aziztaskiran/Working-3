package aziz_taskiran_hw2;

/**
 *
 * @author aziz
 * @param <E>
 */
public class DB<E> extends Node<E> implements DataBase
{
    private Node<E> first;
    public void DB()
    {
        first=null;
    }
    
    @Override
    public Person SearchName(String tName)
    {
        if(first!=null)
        {
            int b;
            Node<E> gecici;
            Node<E> follow=first;
            gecici=first;
            boolean a=gecici.element.GetName().equalsIgnoreCase(tName);
            while(a!= true)
            {
                follow=gecici;
                if(gecici.next==null)
                {
                    return null;
                }
                gecici=gecici.next;
                a=gecici.element.GetName().equalsIgnoreCase(tName);
            }
            boolean n=first.element.GetName().equalsIgnoreCase(tName);
            if(n==true)
            {
                b=first.element.GetHitCount();
                b++;
                first.element.SetHitCount(b);
                return first.element;
            }
            else
            {
                follow.next=gecici.next;
                gecici.next=first;
                first=gecici;
                b=first.element.GetHitCount();
                b++;
                first.element.SetHitCount(b);
                return first.element;
            }
        }
        else
        {
            return null;
        }
    }

    @Override
    public Person SearchSurname(String tSurname) 
    {
        if(first!=null)
        {
            int b;
            Node<E> gecici;
            Node<E> follow=first;
            gecici=first;
            boolean a=gecici.element.GetSurName().equalsIgnoreCase(tSurname);
            while(a!= true)
            {
                follow=gecici;
                if(gecici.next==null)
                {
                    return null;
                }
                gecici=gecici.next;
                a=gecici.element.GetSurName().equalsIgnoreCase(tSurname);
            }
            boolean n=first.element.GetSurName().equalsIgnoreCase(tSurname);
            if(n==true)
            {
                b=first.element.GetHitCount();
                b++;
                first.element.SetHitCount(b);
                return first.element;
            }
            else
            {
                follow.next=gecici.next;
                gecici.next=first;
                first=gecici;
                b=first.element.GetHitCount();
                b++;
                first.element.SetHitCount(b);
                return first.element;
            }
        }
        else
        {
            return null;
        }
    }
    
    @Override
    public Person SearchID(Integer tID)
    {
        if(first != null)
        {
            int a,k,m;
            Node<E> gecici;
            Node<E> follow=first;
            gecici=first;
            k=gecici.element.GetID();
            while(k != tID)
            {
                follow=gecici;
                if(gecici.next==null)
                {
                    return null;
                }
                gecici=gecici.next;
                k=gecici.element.GetID();
            }
            m=first.element.GetID();
            if(m==tID)
            {
                a=first.element.GetHitCount();
                a++;
                first.element.SetHitCount(a);
                return first.element;
            }
            else
            {
                follow.next=gecici.next;
                gecici.next=first;
                first=gecici;
                a=first.element.GetHitCount();
                a++;
                first.element.SetHitCount(a);
                return first.element;
            }
        }
        else
        {
          return null;
        }
    }

    @Override
    public void OutputList()
    {
        Person t;
        int b,k,j,i,a=0,m,c;
        Person[] dizi;
        Node<E> gecici;
        Node<E> gecici2=first;
        gecici=first;
        while(gecici!=null)
        {
            gecici=gecici.next;
            a++;
        }
        dizi=new Person[a];
        gecici=first;
        for(i=0;i<a;i++)
        {
            while(gecici!=null)
            {
                dizi[i]=gecici.element;
                gecici2=gecici;
                gecici=null;
            }
            gecici=gecici2.next;
        }
        for(j=0;j<(a-1);j++)
        {
            for(k=0;k<(a-1);k++)
            {
               if(dizi[k].GetHitCount()<dizi[k+1].GetHitCount())
               {
                   t=dizi[k];
                   dizi[k]=dizi[k+1];
                   dizi[k+1]=t;
               }
            }       
        }
       for(b=0;b<a;b++)
       {
           dizi[b].ContentOut();
           
       }
           
    }

    @Override
    public boolean AddPerson(Person tNewPerson) 
    {
        if(first==null)
        {
            Node newnode= new Node<>();
            newnode.element=tNewPerson;
            first=newnode;
            newnode.element.SetHitCount(0);
        }
        else
        {
            Node newnode= new Node<>();
            newnode.element=tNewPerson;
            Node<E> gecici;
            gecici=first;
            while(gecici.next != null)
            {
                gecici=gecici.next;
            }
            gecici.next=newnode;
            newnode.element.SetHitCount(0);
        }
        return true;
    }

    @Override
    public Person DeletePerson(Integer tID) 
    {
        if(first!=null)
        {
            int k;
            Node<E> gecici;
            Node<E> follow=first;
            gecici=first;
            k=gecici.element.GetID();
            while(k!=tID)
            {
                follow=gecici;
                if(gecici.next==null)
                {
                    return null;
                }
                gecici=gecici.next;
                k=gecici.element.GetID();
            }
            boolean n=first.element.GetID().equals(tID);
            if(n==true)
            {
                first=gecici.next;
                return gecici.element;
            }
            else
            {
                follow.next=gecici.next;
                gecici.next=null;
                return gecici.element;
            }
        }
        else
        {
          return null;
        }
    }
    
    @Override
    public String toString()
    {
        int a=0,b;
        String eleman = new String();
        Node<E> gecici;
        gecici=first;
        
       while(gecici!=null)
        {
            gecici=gecici.next;
            a++;
        }
        gecici=first;
        for(b=0;b<a;b++)
        {
            eleman += "Name :" + gecici.element.GetName() + "\n";
            eleman += "Surname :" + gecici.element.GetSurName() + "\n";
            eleman += "ID :" + gecici.element.GetID() + "\n";
            eleman += "Hit Count :" + gecici.element.GetHitCount() + "\n";
            
            gecici=gecici.next;
        }
        return eleman;
    }
}
