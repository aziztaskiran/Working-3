/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aziz_taskiran_hw2;

/**
 *
 * @author aziz
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        DB MyDB = new DB();
        
        Person new1 = new Person("Ayse", "Kır", 50);
        Person new2 = new Person("Ahmet", "Ozdemir", 100);
        Person new3 = new Person("Aziz", "Taskıran", 150);
        Person new4 = new Person("Betul", "Demir", 200);
        Person new5 = new Person("Bahar", "Tetik", 250);
        Person new6 = new Person("Gokhan", "Kara", 300);
        Person new7 = new Person("Hakan", "Suskun", 350);
        Person new8 = new Person("Mehmet", "Senses", 400);
        
         
        MyDB.AddPerson(new1);
        MyDB.AddPerson(new2);
        MyDB.AddPerson(new3);
        MyDB.AddPerson(new4);
        MyDB.AddPerson(new5);
        MyDB.AddPerson(new6);
        MyDB.AddPerson(new7);
        MyDB.AddPerson(new8);
        
        System.out.println(MyDB.toString());
        
        System.out.println("--------------------------");
       
        MyDB.SearchID(100);
        MyDB.SearchSurname("Kara");
        MyDB.SearchID(250);
        MyDB.SearchName("Ahmet");
        MyDB.SearchName("Betul");
        MyDB.SearchSurname("Ozdemir");
        MyDB.SearchName("Aziz");
        MyDB.SearchSurname("Demir");
        MyDB.SearchID(50);
        MyDB.SearchSurname("Kır");
        MyDB.SearchSurname("Demir");
        MyDB.SearchID(200);
        MyDB.SearchName("Ayse");
        MyDB.SearchID(350);
        MyDB.SearchName("Bahar");
        MyDB.SearchSurname("Taskıran");
        MyDB.SearchName("Gokhan");
        
       System.out.println(MyDB.toString());
        
       System.out.println("--------------------------");
      
       MyDB.OutputList();
        
       System.out.println("--------------------------");
       
       System.out.println(MyDB.toString());
        
       System.out.println("--------------------------");
        
       MyDB.OutputList();
       
       MyDB.SearchName("Ayse");
       
       MyDB.DeletePerson(400);
        
       System.out.println("--------------------------");
        
       System.out.println(MyDB.toString());
        
       System.out.println("--------------------------");
       
       MyDB.OutputList();
       
       System.out.println("--------------------------");
        
       System.out.println(MyDB.toString());
       
    }
    
}
