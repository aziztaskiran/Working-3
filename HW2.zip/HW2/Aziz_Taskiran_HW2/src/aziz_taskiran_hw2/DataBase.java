/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aziz_taskiran_hw2;

/**
 *
 * @author aziz
 */
public interface DataBase 
{
    public Person SearchName(String tName); // Will return the Person object if Name is found
    public Person SearchSurname(String tSurname);
    public Person SearchID(Integer tID);
    public void OutputList(); // Print elements in descending order in the linked list
    public boolean AddPerson(Person tNewPerson); // Add new person into tail of the link list
    public Person DeletePerson(Integer tID); //The Person will be deleted if it is in the list
    @Override
    public String toString(); // Print Elements in the link list. No order
 
    
}
